<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Random Name Generator</title>
  <link rel='stylesheet' href='./index.css'>
</head>

<body>
  <h1>Random names generated:</h1>
  <?php
  if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nationality = $_POST['nationality'];
    $amount = $_POST['amount'];

    $user_response = file_get_contents("https://randomuser.me/api/?nat=$nationality&results=$amount&format=json");
    $data_array = json_decode($user_response, true);

    $generatedNames = [];
    for ($i = 0; $i < $amount; $i++) {
      $full_name = $data_array['results'][$i]['name']['title'] . " " . $data_array['results'][$i]['name']['first'] . " " . $data_array['results'][$i]['name']['last'];
      $generatedNames[] = $full_name;
    }

    foreach ($generatedNames as $name) {
      echo "<h5>$name</h5>";
    }

    $information = $_POST['information'] ?? '';

    if ($information !== '') {
      // Process selected information (e.g., gender, address, etc.) here
      // Your code to display the selected information goes here
    }
  }
  ?>

  <br>
  <div class="questions">
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
      <label for="nationality">Nationality:</label>
      <input type="text" name="nationality">
      <br>
      <label for="amount">Amount:</label>
      <input type="number" name="amount" min="1" max="10">
      <br>
      <label for="information">What information would you like to find out about these people?</label>
      <br>
      <select name="information" id="information">
        <option value="">Select one</option>
        <option value="gender">Gender</option>
        <option value="address">Address</option>
        <option value="email">Email</option>
        <option value="dob">Date of Birth</option>
        <option value="phone">Telephone Number</option>
        <option value="cell">Cellphone Number</option>
        <option value="nationality">Nationality</option>
      </select>
      <button type='submit'>Submit Query</button>
    </form>
  </div>
  <br>
</body>
</html>